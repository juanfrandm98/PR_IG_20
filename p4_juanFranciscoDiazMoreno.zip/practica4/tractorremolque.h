#ifndef TRACTORREMOLQUE_H_INCLUDED
#define TRACTORREMOLQUE_H_INCLUDED

#include "modelojerarquico.h"

class TractorRemolque : public ModeloJerarquico {

public:
  TractorRemolque();

};

#endif
