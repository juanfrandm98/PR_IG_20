#ifndef COPA_H_INCLUDED
#define COPA_H_INCLUDED

#include "partemodelojerarquico.h"
#include "malla.h"
#include "objrevolucion.h"
#include "cono.h"

class Copa : public ParteModeloJerarquico {

public:
  Copa();

};

#endif
