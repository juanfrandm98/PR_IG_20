#include "tractorremolque.h"
#include "modelojerarquico.h"

TractorRemolque::TractorRemolque() {

  //componentes.push_back( new Cubo( 100 ) );
  //componentes.push_back( new Cilindro( 10, 10, 200, 50 ) );

}
