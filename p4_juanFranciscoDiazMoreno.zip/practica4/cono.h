#ifndef CONO_H_INCLUDED
#define CONO_H_INCLUDED

#include "aux.h"

class Cono : public ObjRevolucion
{
   public:
   Cono( const int numVertPerfil, const int numInstanciasPerf,
             const float altura, const float radio ) ;

} ;

#endif
