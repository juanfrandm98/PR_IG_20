#ifndef ESFERA_H_INCLUDED
#define ESFERA_H_INCLUDED

#include "aux.h"

class Esfera : public ObjRevolucion
{
   public:
   Esfera( const int numVertPerfil, const int numInstanciasPerf,
           const float radio ) ;

} ;

#endif
